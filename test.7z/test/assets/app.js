/**
 * Основной JavaScript файл для дневника питания
 * Содержит логику динамического добавления ингредиентов, автокалькуляции калорий,
 * AJAX запросы для переноса блюд и отметки ингредиентов
 */

// Глобальный счётчик для индексов ингредиентов
let ingredientIndex = 0;

/**
 * Инициализация формы блюда (создание/редактирование)
 */
function initDishForm() {
    const addBtn = document.getElementById('add-ingredient-btn');
    const ingredientsList = document.getElementById('ingredients-list');
    
    if (!addBtn || !ingredientsList) return;
    
    // Инициализируем индекс на основе существующих ингредиентов
    const existingRows = ingredientsList.querySelectorAll('.ingredient-row');
    ingredientIndex = existingRows.length > 0 
        ? Math.max(...Array.from(existingRows).map(r => parseInt(r.dataset.index) || 0)) + 1
        : Date.now();
    
    // Обработчик добавления ингредиента
    addBtn.addEventListener('click', addIngredientRow);
    
    // Обработчики для существующих ингредиентов
    ingredientsList.addEventListener('input', handleIngredientInput);
    ingredientsList.addEventListener('click', handleIngredientClick);
    
    // Инициализируем автокалькуляцию для существующих полей
    initAutoCalculation();
}

/**
 * Добавление новой строки ингредиента
 */
function addIngredientRow() {
    const ingredientsList = document.getElementById('ingredients-list');
    if (!ingredientsList) return;
    
    const index = ingredientIndex++;
    const row = document.createElement('div');
    row.className = 'ingredient-row';
    row.dataset.index = index;
    
    row.innerHTML = `
        <div class="ingredient-fields">
            <input type="text" name="ingredients[${index}][name]" 
                   placeholder="Название (опц.)">
            <input type="number" name="ingredients[${index}][grams]" 
                   placeholder="Граммы *" step="0.1" min="0.1" required
                   class="grams-input">
            <input type="number" name="ingredients[${index}][kcal_per_100]" 
                   placeholder="ккал/100г (опц.)" step="0.1" min="0"
                   class="kcal-per-100-input">
            <input type="number" name="ingredients[${index}][kcal]" 
                   placeholder="ккал *" step="0.1" min="0" required
                   class="kcal-input">
            <input type="number" name="ingredients[${index}][protein]" 
                   placeholder="Белки" step="0.1" min="0">
            <input type="number" name="ingredients[${index}][fat]" 
                   placeholder="Жиры" step="0.1" min="0">
            <input type="number" name="ingredients[${index}][carbs]" 
                   placeholder="Углеводы" step="0.1" min="0">
            <label class="checkbox-label">
                <input type="checkbox" name="ingredients[${index}][calculated_flag]">
                Калории посчитаны
            </label>
            <button type="button" class="btn btn-small btn-danger remove-ingredient-btn">🗑️</button>
        </div>
    `;
    
    ingredientsList.appendChild(row);
    
    // Фокус на поле граммов
    const gramsInput = row.querySelector('.grams-input');
    if (gramsInput) gramsInput.focus();
}

/**
 * Обработка ввода в полях ингредиента
 */
function handleIngredientInput(e) {
    if (e.target.classList.contains('kcal-per-100-input') || 
        e.target.classList.contains('grams-input')) {
        calculateKcal(e.target);
    }
}

/**
 * Обработка кликов (удаление ингредиента)
 */
function handleIngredientClick(e) {
    if (e.target.classList.contains('remove-ingredient-btn')) {
        const row = e.target.closest('.ingredient-row');
        if (row) {
            row.remove();
        }
    }
}

/**
 * Автоматический расчёт калорий
 * kcal = (kcal_per_100 * grams) / 100
 */
function calculateKcal(input) {
    const row = input.closest('.ingredient-row');
    if (!row) return;
    
    const kcalPer100Input = row.querySelector('.kcal-per-100-input');
    const gramsInput = row.querySelector('.grams-input');
    const kcalInput = row.querySelector('.kcal-input');
    
    if (!kcalPer100Input || !gramsInput || !kcalInput) return;
    
    const kcalPer100 = parseFloat(kcalPer100Input.value) || 0;
    const grams = parseFloat(gramsInput.value) || 0;
    
    // Если указаны ккал/100г и граммы, считаем автоматически
    if (kcalPer100 > 0 && grams > 0) {
        const calculatedKcal = (kcalPer100 * grams) / 100;
        kcalInput.value = calculatedKcal.toFixed(1);
    }
}

/**
 * Инициализация автокалькуляции для всех существующих полей
 */
function initAutoCalculation() {
    const ingredientsList = document.getElementById('ingredients-list');
    if (!ingredientsList) return;
    
    const kcalPer100Inputs = ingredientsList.querySelectorAll('.kcal-per-100-input');
    const gramsInputs = ingredientsList.querySelectorAll('.grams-input');
    
    kcalPer100Inputs.forEach(input => {
        input.addEventListener('input', () => calculateKcal(input));
    });
    
    gramsInputs.forEach(input => {
        input.addEventListener('input', () => calculateKcal(input));
    });
}

/**
 * Инициализация кнопок переноса блюда на предыдущий день
 */
function initShiftBackButtons() {
    const buttons = document.querySelectorAll('.shift-back-btn');
    
    buttons.forEach(button => {
        button.addEventListener('click', async function() {
            const dishId = this.dataset.dishId;
            const dishName = this.dataset.dishName || 'блюдо';
            
            if (!dishId) return;
            
            if (!confirm(`Перенести "${dishName}" на предыдущий день?`)) {
                return;
            }
            
            // Блокируем кнопку
            this.disabled = true;
            const originalText = this.textContent;
            this.textContent = '⏳ Перенос...';
            
            try {
                const formData = new FormData();
                formData.append('dish_id', dishId);
                
                const response = await fetch('api/shift_back.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Перезагружаем страницу для обновления группировки
                    location.reload();
                } else {
                    alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
                    this.disabled = false;
                    this.textContent = originalText;
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Ошибка при переносе блюда');
                this.disabled = false;
                this.textContent = originalText;
            }
        });
    });
}

/**
 * Инициализация кнопок отметки ингредиента как "посчитан"
 */
function initToggleCalculatedButtons() {
    const buttons = document.querySelectorAll('.toggle-calculated-btn');
    
    buttons.forEach(button => {
        button.addEventListener('click', async function() {
            const ingredientId = this.dataset.ingredientId;
            
            if (!ingredientId) return;
            
            // Блокируем кнопку
            this.disabled = true;
            const originalText = this.textContent;
            this.textContent = '⏳...';
            
            try {
                const formData = new FormData();
                formData.append('ingredient_id', ingredientId);
                
                const response = await fetch('api/toggle_calculated.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Обновляем UI
                    const row = this.closest('.ingredient-row');
                    if (row) {
                        row.classList.add('calculated');
                        const cell = this.parentElement;
                        cell.innerHTML = '<span class="badge badge-success">✓ Посчитано</span>';
                    }
                } else {
                    alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
                    this.disabled = false;
                    this.textContent = originalText;
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Ошибка при отметке ингредиента');
                this.disabled = false;
                this.textContent = originalText;
            }
        });
    });
}

/**
 * Валидация формы перед отправкой
 */
function validateDishForm() {
    const form = document.getElementById('dish-form');
    if (!form) return true;
    
    const name = form.querySelector('#name');
    if (!name || !name.value.trim()) {
        alert('Введите название блюда');
        if (name) name.focus();
        return false;
    }
    
    const ingredientsList = document.getElementById('ingredients-list');
    if (!ingredientsList) return true;
    
    const ingredientRows = ingredientsList.querySelectorAll('.ingredient-row');
    if (ingredientRows.length === 0) {
        alert('Добавьте хотя бы один ингредиент');
        return false;
    }
    
    // Проверяем обязательные поля в каждом ингредиенте
    let hasErrors = false;
    ingredientRows.forEach((row, index) => {
        const grams = row.querySelector('[name*="[grams]"]');
        const kcal = row.querySelector('[name*="[kcal]"]');
        
        if (!grams || !grams.value || parseFloat(grams.value) <= 0) {
            alert(`Ингредиент #${index + 1}: укажите граммы (положительное число)`);
            hasErrors = true;
            if (grams) grams.focus();
        }
        
        if (!kcal || !kcal.value || parseFloat(kcal.value) < 0) {
            alert(`Ингредиент #${index + 1}: укажите калории (неотрицательное число)`);
            hasErrors = true;
            if (kcal && !hasErrors) kcal.focus();
        }
    });
    
    return !hasErrors;
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация формы блюда (если есть)
    if (document.getElementById('dish-form')) {
        initDishForm();
        
        // Валидация перед отправкой
        const form = document.getElementById('dish-form');
        form.addEventListener('submit', function(e) {
            if (!validateDishForm()) {
                e.preventDefault();
                return false;
            }
        });
    }
    
    // Инициализация кнопок переноса блюда
    initShiftBackButtons();
    
    // Инициализация кнопок отметки ингредиентов
    initToggleCalculatedButtons();
});

