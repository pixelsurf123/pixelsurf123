import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # SQLite configuration
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATABASE_NAME = os.environ.get('DATABASE_NAME') or 'food_diary.db'
    DATABASE_PATH = os.path.join(BASE_DIR, DATABASE_NAME)
    
    SQLALCHEMY_DATABASE_URI = f'sqlite:///{DATABASE_PATH}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

