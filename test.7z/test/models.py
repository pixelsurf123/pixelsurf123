from datetime import datetime, timedelta
from db import db

class Dish(db.Model):
    __tablename__ = 'dishes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    # Relationship
    ingredients = db.relationship('Ingredient', backref='dish', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'created_at': self.created_at.isoformat(),
            'total_kcal': sum(ing.kcal for ing in self.ingredients),
            'ingredients': [ing.to_dict() for ing in self.ingredients]
        }
    
    def get_total_kcal(self):
        """Возвращает общее количество калорий в блюде"""
        total = 0
        for ing in self.ingredients:
            if ing.kcal is not None:
                total += ing.kcal
        return total
    
    def shift_back_one_day(self):
        """Переносит блюдо на предыдущий день"""
        self.created_at = self.created_at - timedelta(days=1)
        db.session.commit()
        return self
    
    def shift_forward_one_day(self):
        """Переносит блюдо на следующий день"""
        self.created_at = self.created_at + timedelta(days=1)
        db.session.commit()
        return self

class Ingredient(db.Model):
    __tablename__ = 'ingredients'
    
    id = db.Column(db.Integer, primary_key=True)
    dish_id = db.Column(db.Integer, db.ForeignKey('dishes.id', ondelete='CASCADE'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    grams = db.Column(db.Float, nullable=False)
    kcal = db.Column(db.Float, nullable=False)
    kcal_per_100 = db.Column(db.Float, nullable=True)
    protein = db.Column(db.Float, nullable=True)
    fat = db.Column(db.Float, nullable=True)
    carbs = db.Column(db.Float, nullable=True)
    calculated_flag = db.Column(db.Boolean, default=False, nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'dish_id': self.dish_id,
            'name': self.name,
            'grams': self.grams,
            'kcal': self.kcal,
            'kcal_per_100': self.kcal_per_100,
            'protein': self.protein,
            'fat': self.fat,
            'carbs': self.carbs,
            'calculated_flag': self.calculated_flag
        }
    
    def toggle_calculated(self):
        """Переключает флаг calculated_flag"""
        self.calculated_flag = not self.calculated_flag
        db.session.commit()
        return self

