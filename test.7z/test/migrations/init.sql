-- Миграция для создания таблиц базы данных MySQL
-- Счётчик калорий - дневник питания

-- Таблица блюд
CREATE TABLE IF NOT EXISTS dish (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    note VARCHAR(255),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Таблица ингредиентов
CREATE TABLE IF NOT EXISTS ingredient (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dish_id INT NOT NULL,
    name VARCHAR(255),
    grams DECIMAL(10,2) NOT NULL,
    kcal_per_100 DECIMAL(10,2),
    kcal DECIMAL(10,2) NOT NULL,
    protein DECIMAL(10,2) DEFAULT 0,
    fat DECIMAL(10,2) DEFAULT 0,
    carbs DECIMAL(10,2) DEFAULT 0,
    calculated_flag TINYINT(1) DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dish_id) REFERENCES dish(id) ON DELETE CASCADE,
    INDEX idx_dish_id (dish_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Тестовые данные

-- Блюдо 1: Омлет (сегодняшнее)
INSERT INTO dish (name, created_at, note) VALUES 
('Омлет', NOW(), 'Завтрак');

-- Ингредиенты для омлета
INSERT INTO ingredient (dish_id, name, grams, kcal_per_100, kcal, protein, fat, carbs, calculated_flag) VALUES
((SELECT id FROM dish WHERE name = 'Омлет' ORDER BY id DESC LIMIT 1), 'Яйцо куриное', 100, 157, 157, 12.7, 11.5, 0.7, 1),
((SELECT id FROM dish WHERE name = 'Омлет' ORDER BY id DESC LIMIT 1), 'Молоко 3.2%', 50, 64, 32, 2.8, 3.2, 4.7, 1);

-- Блюдо 2: Овсянка (вчерашнее)
INSERT INTO dish (name, created_at, note) VALUES 
('Овсянка с фруктами', DATE_SUB(NOW(), INTERVAL 1 DAY), 'Завтрак');

-- Ингредиенты для овсянки
INSERT INTO ingredient (dish_id, name, grams, kcal_per_100, kcal, protein, fat, carbs, calculated_flag) VALUES
((SELECT id FROM dish WHERE name = 'Овсянка с фруктами' ORDER BY id DESC LIMIT 1), 'Овсяные хлопья', 50, 389, 194.5, 13.0, 6.9, 66.0, 1),
((SELECT id FROM dish WHERE name = 'Овсянка с фруктами' ORDER BY id DESC LIMIT 1), 'Бананы', 100, 89, 89, 1.1, 0.3, 22.8, 1),
((SELECT id FROM dish WHERE name = 'Овсянка с фруктами' ORDER BY id DESC LIMIT 1), 'Мёд', 20, 304, 60.8, 0.3, 0.0, 82.0, 0);

-- Блюдо 3: Салат (сегодняшнее)
INSERT INTO dish (name, created_at, note) VALUES 
('Салат овощной', NOW(), 'Обед');

-- Ингредиенты для салата
INSERT INTO ingredient (dish_id, name, grams, kcal_per_100, kcal, protein, fat, carbs, calculated_flag) VALUES
((SELECT id FROM dish WHERE name = 'Салат овощной' ORDER BY id DESC LIMIT 1), 'Помидоры', 150, 20, 30, 0.6, 0.2, 4.2, 1),
((SELECT id FROM dish WHERE name = 'Салат овощной' ORDER BY id DESC LIMIT 1), 'Огурцы', 100, 16, 16, 0.8, 0.1, 2.5, 1),
((SELECT id FROM dish WHERE name = 'Салат овощной' ORDER BY id DESC LIMIT 1), 'Масло оливковое', 10, 884, 88.4, 0.0, 100.0, 0.0, 1);
