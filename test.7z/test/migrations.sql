-- Создание базы данных для дневника питания
-- SQLite

-- Таблица блюд
CREATE TABLE IF NOT EXISTS dishes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_created_at ON dishes(created_at);

-- Таблица ингредиентов
CREATE TABLE IF NOT EXISTS ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dish_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    grams REAL NOT NULL,
    kcal REAL NOT NULL,
    kcal_per_100 REAL NULL,
    protein REAL NULL,
    fat REAL NULL,
    carbs REAL NULL,
    calculated_flag BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (dish_id) REFERENCES dishes(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_dish_id ON ingredients(dish_id);

-- Тестовые данные

-- Блюдо "Омлет" (сегодня)
INSERT INTO dishes (name, created_at) VALUES 
('Омлет', datetime('now'));

INSERT INTO ingredients (dish_id, name, grams, kcal, kcal_per_100, protein, fat, carbs, calculated_flag) VALUES
((SELECT id FROM dishes WHERE name = 'Омлет' LIMIT 1), 'Яйцо куриное', 120, 180, 150, 15.0, 12.0, 1.2, 1),
((SELECT id FROM dishes WHERE name = 'Омлет' LIMIT 1), 'Молоко', 50, 26, 52, 2.6, 1.0, 4.7, 1),
((SELECT id FROM dishes WHERE name = 'Омлет' LIMIT 1), 'Масло сливочное', 10, 75, 750, 0.1, 8.2, 0.1, 1);

-- Блюдо "Овсянка" (вчера)
INSERT INTO dishes (name, created_at) VALUES 
('Овсянка', datetime('now', '-1 day'));

INSERT INTO ingredients (dish_id, name, grams, kcal, kcal_per_100, protein, fat, carbs, calculated_flag) VALUES
((SELECT id FROM dishes WHERE name = 'Овсянка' LIMIT 1), 'Овсяные хлопья', 80, 280, 350, 11.2, 6.0, 55.0, 1),
((SELECT id FROM dishes WHERE name = 'Овсянка' LIMIT 1), 'Молоко', 200, 104, 52, 10.4, 4.0, 18.8, 1),
((SELECT id FROM dishes WHERE name = 'Овсянка' LIMIT 1), 'Мед', 20, 64, 320, 0.2, 0.0, 16.0, 1);

-- Блюдо "Чай" (сегодня, позже)
INSERT INTO dishes (name, created_at) VALUES 
('Чай', datetime('now', '+1 hour'));

INSERT INTO ingredients (dish_id, name, grams, kcal, kcal_per_100, protein, fat, carbs, calculated_flag) VALUES
((SELECT id FROM dishes WHERE name = 'Чай' LIMIT 1), 'Чай черный', 250, 2, 1, 0.0, 0.0, 0.0, 1),
((SELECT id FROM dishes WHERE name = 'Чай' LIMIT 1), 'Сахар', 10, 40, 400, 0.0, 0.0, 10.0, 1);
