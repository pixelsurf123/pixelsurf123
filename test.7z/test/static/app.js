// Глобальный счетчик для ингредиентов
let ingredientIndex = 0;

// Добавление нового ингредиента
function addIngredient() {
    const container = document.getElementById('ingredients-container');
    if (!container) return;
    
    const row = document.createElement('div');
    row.className = 'ingredient-row';
    row.setAttribute('data-index', ingredientIndex++);
    
    row.innerHTML = `
        <div class="ingredient-fields">
            <input type="text" name="ingredient_name[]" placeholder="Название" required class="ingredient-name-input">
            <input type="number" name="ingredient_grams[]" placeholder="Граммы" 
                   step="0.1" class="grams-input">
            <input type="number" name="ingredient_kcal_per_100[]" placeholder="Ккал/100г" 
                   step="0.1" class="kcal-per-100-input">
            <input type="number" name="ingredient_kcal[]" placeholder="Ккал" 
                   step="0.1" required class="kcal-input">
            <input type="number" name="ingredient_protein[]" placeholder="Белки" 
                   step="0.1" class="protein-input">
            <input type="number" name="ingredient_fat[]" placeholder="Жиры" 
                   step="0.1" class="fat-input">
            <input type="number" name="ingredient_carbs[]" placeholder="Углеводы" 
                   step="0.1" class="carbs-input">
            <button type="button" class="btn btn-remove" onclick="removeIngredient(this)" title="Удалить">×</button>
        </div>
        <div class="ingredient-options">
            <button type="button" class="btn btn-toggle-mode" onclick="toggleDirectKcalMode(this)">
                ✓ Калории уже посчитаны
            </button>
        </div>
    `;
    
    container.appendChild(row);
    
    // Добавляем обработчики событий для автокалькуляции
    setupIngredientCalculations(row);
}

// Переключение режима "калории уже посчитаны"
function toggleDirectKcalMode(button) {
    const row = button.closest('.ingredient-row');
    const gramsInput = row.querySelector('.grams-input');
    const kcalPer100Input = row.querySelector('.kcal-per-100-input');
    const kcalInput = row.querySelector('.kcal-input');
    
    if (button.classList.contains('active')) {
        // Включаем режим расчета
        button.classList.remove('active');
        button.textContent = '✓ Калории уже посчитаны';
        gramsInput.required = true;
        gramsInput.disabled = false;
        gramsInput.style.opacity = '1';
        kcalPer100Input.disabled = false;
        kcalPer100Input.style.opacity = '1';
    } else {
        // Включаем режим прямого ввода калорий
        button.classList.add('active');
        button.textContent = '✗ Режим расчета';
        gramsInput.required = false;
        gramsInput.disabled = true;
        gramsInput.style.opacity = '0.5';
        gramsInput.value = '';
        kcalPer100Input.disabled = true;
        kcalPer100Input.style.opacity = '0.5';
        kcalPer100Input.value = '';
        kcalInput.focus();
    }
}

// Удаление ингредиента
function removeIngredient(button) {
    const row = button.closest('.ingredient-row');
    if (row) {
        row.remove();
    }
}

// Настройка автокалькуляции для ингредиента
function setupIngredientCalculations(row) {
    const kcalPer100Input = row.querySelector('.kcal-per-100-input');
    const gramsInput = row.querySelector('.grams-input');
    const kcalInput = row.querySelector('.kcal-input');
    
    if (!kcalPer100Input || !gramsInput || !kcalInput) return;
    
    // Функция расчета калорий
    function calculateKcal() {
        // Не считаем, если режим "калории уже посчитаны" активен
        const toggleBtn = row.querySelector('.btn-toggle-mode');
        if (toggleBtn && toggleBtn.classList.contains('active')) {
            return;
        }
        
        const kcalPer100 = parseFloat(kcalPer100Input.value) || 0;
        const grams = parseFloat(gramsInput.value) || 0;
        
        if (kcalPer100 > 0 && grams > 0) {
            const calculatedKcal = (kcalPer100 * grams) / 100;
            kcalInput.value = calculatedKcal.toFixed(1);
        }
    }
    
    // Слушаем изменения в полях
    kcalPer100Input.addEventListener('input', calculateKcal);
    gramsInput.addEventListener('input', calculateKcal);
}

// Инициализация автокалькуляции для существующих ингредиентов
document.addEventListener('DOMContentLoaded', function() {
    const ingredientRows = document.querySelectorAll('.ingredient-row');
    ingredientRows.forEach(row => {
        setupIngredientCalculations(row);
        
        // Инициализируем состояние кнопки переключения режима
        const toggleBtn = row.querySelector('.btn-toggle-mode');
        if (toggleBtn && toggleBtn.classList.contains('active')) {
            const gramsInput = row.querySelector('.grams-input');
            const kcalPer100Input = row.querySelector('.kcal-per-100-input');
            if (gramsInput) {
                gramsInput.disabled = true;
                gramsInput.style.opacity = '0.5';
            }
            if (kcalPer100Input) {
                kcalPer100Input.disabled = true;
                kcalPer100Input.style.opacity = '0.5';
            }
        }
    });
    
    // Устанавливаем начальный индекс
    ingredientIndex = ingredientRows.length;
});

// Перенос блюда на предыдущий день
function shiftDishBack(dishId) {
    if (!confirm('Перенести блюдо на предыдущий день?')) {
        return;
    }
    
    fetch(`/api/shift_back/${dishId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Перезагружаем страницу для обновления группировки
            window.location.reload();
        } else {
            alert('Ошибка: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Произошла ошибка при переносе блюда');
    });
}

// Перенос блюда на следующий день
function shiftDishForward(dishId) {
    if (!confirm('Перенести блюдо на следующий день?')) {
        return;
    }
    
    fetch(`/api/shift_forward/${dishId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Перезагружаем страницу для обновления группировки
            window.location.reload();
        } else {
            alert('Ошибка: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Произошла ошибка при переносе блюда');
    });
}

// Переключение флага calculated для ингредиента
function toggleCalculated(ingredientId) {
    fetch(`/api/toggle_calculated/${ingredientId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Перезагружаем страницу для обновления статуса
            window.location.reload();
        } else {
            alert('Ошибка: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Произошла ошибка при обновлении статуса');
    });
}

