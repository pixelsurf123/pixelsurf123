"""
Скрипт для инициализации базы данных SQLite с тестовыми данными
"""
from app import create_app
from db import db
from models import Dish, Ingredient
from datetime import datetime, timedelta

def init_database():
    """Создает таблицы и заполняет тестовыми данными"""
    app = create_app()
    
    with app.app_context():
        # Удаляем все таблицы (если нужно пересоздать)
        db.drop_all()
        
        # Создаем таблицы
        db.create_all()
        
        # Создаем тестовые данные
        
        # Блюдо "Омлет" (сегодня)
        omlet = Dish(name='Омлет', created_at=datetime.now())
        db.session.add(omlet)
        db.session.flush()
        
        db.session.add(Ingredient(
            dish_id=omlet.id,
            name='Яйцо куриное',
            grams=120,
            kcal=180,
            kcal_per_100=150,
            protein=15.0,
            fat=12.0,
            carbs=1.2,
            calculated_flag=True
        ))
        db.session.add(Ingredient(
            dish_id=omlet.id,
            name='Молоко',
            grams=50,
            kcal=26,
            kcal_per_100=52,
            protein=2.6,
            fat=1.0,
            carbs=4.7,
            calculated_flag=True
        ))
        db.session.add(Ingredient(
            dish_id=omlet.id,
            name='Масло сливочное',
            grams=10,
            kcal=75,
            kcal_per_100=750,
            protein=0.1,
            fat=8.2,
            carbs=0.1,
            calculated_flag=True
        ))
        
        # Блюдо "Овсянка" (вчера)
        oatmeal = Dish(name='Овсянка', created_at=datetime.now() - timedelta(days=1))
        db.session.add(oatmeal)
        db.session.flush()
        
        db.session.add(Ingredient(
            dish_id=oatmeal.id,
            name='Овсяные хлопья',
            grams=80,
            kcal=280,
            kcal_per_100=350,
            protein=11.2,
            fat=6.0,
            carbs=55.0,
            calculated_flag=True
        ))
        db.session.add(Ingredient(
            dish_id=oatmeal.id,
            name='Молоко',
            grams=200,
            kcal=104,
            kcal_per_100=52,
            protein=10.4,
            fat=4.0,
            carbs=18.8,
            calculated_flag=True
        ))
        db.session.add(Ingredient(
            dish_id=oatmeal.id,
            name='Мед',
            grams=20,
            kcal=64,
            kcal_per_100=320,
            protein=0.2,
            fat=0.0,
            carbs=16.0,
            calculated_flag=True
        ))
        
        # Блюдо "Чай" (сегодня, позже)
        tea = Dish(name='Чай', created_at=datetime.now() + timedelta(hours=1))
        db.session.add(tea)
        db.session.flush()
        
        db.session.add(Ingredient(
            dish_id=tea.id,
            name='Чай черный',
            grams=250,
            kcal=2,
            kcal_per_100=1,
            protein=0.0,
            fat=0.0,
            carbs=0.0,
            calculated_flag=True
        ))
        db.session.add(Ingredient(
            dish_id=tea.id,
            name='Сахар',
            grams=10,
            kcal=40,
            kcal_per_100=400,
            protein=0.0,
            fat=0.0,
            carbs=10.0,
            calculated_flag=True
        ))
        
        # Сохраняем изменения
        db.session.commit()
        
        print("✅ База данных успешно инициализирована!")
        print(f"📊 Создано блюд: {Dish.query.count()}")
        print(f"📊 Создано ингредиентов: {Ingredient.query.count()}")

if __name__ == '__main__':
    init_database()

