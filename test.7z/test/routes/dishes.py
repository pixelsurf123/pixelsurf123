from flask import Blueprint, render_template, request, redirect, url_for, flash
from db import db
from models import Dish, Ingredient
from datetime import datetime, timedelta
from sqlalchemy import desc
from sqlalchemy.orm import joinedload

dishes_bp = Blueprint('dishes', __name__)

@dishes_bp.route('/')
def index():
    """Главная страница - список блюд, сгруппрованных по дням"""
    # Получаем все блюда с ингредиентами, отсортированные по дате (новые сверху)
    dishes = Dish.query.options(joinedload(Dish.ingredients)).order_by(desc(Dish.created_at)).all()
    
    # Группируем по дням и считаем калории для каждого блюда
    dishes_by_date = {}
    daily_totals = {}  # Итоги за каждый день
    
    for dish in dishes:
        date_key = dish.created_at.date()
        if date_key not in dishes_by_date:
            dishes_by_date[date_key] = []
            daily_totals[date_key] = {
                'kcal': 0,
                'protein': 0,
                'fat': 0,
                'carbs': 0
            }
        
        # Считаем калории и БЖУ для блюда
        dish.total_kcal = sum(ing.kcal or 0 for ing in dish.ingredients)
        dish.total_protein = sum(ing.protein or 0 for ing in dish.ingredients)
        dish.total_fat = sum(ing.fat or 0 for ing in dish.ingredients)
        dish.total_carbs = sum(ing.carbs or 0 for ing in dish.ingredients)
        
        # Добавляем к итогам дня
        daily_totals[date_key]['kcal'] += dish.total_kcal
        daily_totals[date_key]['protein'] += dish.total_protein
        daily_totals[date_key]['fat'] += dish.total_fat
        daily_totals[date_key]['carbs'] += dish.total_carbs
        
        dishes_by_date[date_key].append(dish)
    
    # Сортируем даты по убыванию
    sorted_dates = sorted(dishes_by_date.keys(), reverse=True)
    
    # Форматируем даты для отображения
    today = datetime.now().date()
    yesterday = today - timedelta(days=1)
    
    return render_template('index.html', 
                         dishes_by_date=dishes_by_date,
                         sorted_dates=sorted_dates,
                         daily_totals=daily_totals,
                         today=today,
                         yesterday=yesterday)

@dishes_bp.route('/dish/create', methods=['GET', 'POST'])
def dish_create():
    """Создание нового блюда"""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        
        if not name:
            flash('Название блюда обязательно', 'error')
            return render_template('dish_create.html')
        
        # Создаем блюдо (дата ставится автоматически)
        dish = Dish(name=name)
        db.session.add(dish)
        db.session.flush()  # Получаем ID блюда
        
        # Обрабатываем ингредиенты
        ingredient_names = request.form.getlist('ingredient_name[]')
        ingredient_grams = request.form.getlist('ingredient_grams[]')
        ingredient_kcal = request.form.getlist('ingredient_kcal[]')
        ingredient_kcal_per_100 = request.form.getlist('ingredient_kcal_per_100[]')
        ingredient_protein = request.form.getlist('ingredient_protein[]')
        ingredient_fat = request.form.getlist('ingredient_fat[]')
        ingredient_carbs = request.form.getlist('ingredient_carbs[]')
        
        for i in range(len(ingredient_names)):
            name_ing = ingredient_names[i].strip()
            if not name_ing:
                continue
            
            try:
                # Граммы могут быть пустыми, если используется режим "калории уже посчитаны"
                grams_str = ingredient_grams[i].strip() if i < len(ingredient_grams) and ingredient_grams[i] else ''
                grams = float(grams_str) if grams_str else 0
                
                kcal = float(ingredient_kcal[i] or 0)
                kcal_per_100 = float(ingredient_kcal_per_100[i]) if (i < len(ingredient_kcal_per_100) and ingredient_kcal_per_100[i] and ingredient_kcal_per_100[i].strip()) else None
                protein = float(ingredient_protein[i]) if (i < len(ingredient_protein) and ingredient_protein[i] and ingredient_protein[i].strip()) else None
                fat = float(ingredient_fat[i]) if (i < len(ingredient_fat) and ingredient_fat[i] and ingredient_fat[i].strip()) else None
                carbs = float(ingredient_carbs[i]) if (i < len(ingredient_carbs) and ingredient_carbs[i] and ingredient_carbs[i].strip()) else None
                
                ingredient = Ingredient(
                    dish_id=dish.id,
                    name=name_ing,
                    grams=grams,
                    kcal=kcal,
                    kcal_per_100=kcal_per_100,
                    protein=protein,
                    fat=fat,
                    carbs=carbs,
                    calculated_flag=bool(kcal_per_100)
                )
                db.session.add(ingredient)
            except (ValueError, IndexError):
                continue
        
        db.session.commit()
        flash('Блюдо успешно создано!', 'success')
        return redirect(url_for('dishes.dish_view', id=dish.id))
    
    return render_template('dish_create.html')

@dishes_bp.route('/dish/<int:id>')
def dish_view(id):
    """Просмотр блюда"""
    dish = Dish.query.get_or_404(id)
    total_kcal = sum(ing.kcal or 0 for ing in dish.ingredients)
    total_protein = sum(ing.protein or 0 for ing in dish.ingredients)
    total_fat = sum(ing.fat or 0 for ing in dish.ingredients)
    total_carbs = sum(ing.carbs or 0 for ing in dish.ingredients)
    
    return render_template('dish_view.html',
                         dish=dish,
                         total_kcal=total_kcal,
                         total_protein=total_protein,
                         total_fat=total_fat,
                         total_carbs=total_carbs)

@dishes_bp.route('/dish/<int:id>/edit', methods=['GET', 'POST'])
def dish_edit(id):
    """Редактирование блюда"""
    dish = Dish.query.get_or_404(id)
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        
        if not name:
            flash('Название блюда обязательно', 'error')
            return render_template('dish_edit.html', dish=dish)
        
        dish.name = name
        
        # Удаляем старые ингредиенты
        Ingredient.query.filter_by(dish_id=dish.id).delete()
        
        # Добавляем новые ингредиенты
        ingredient_names = request.form.getlist('ingredient_name[]')
        ingredient_grams = request.form.getlist('ingredient_grams[]')
        ingredient_kcal = request.form.getlist('ingredient_kcal[]')
        ingredient_kcal_per_100 = request.form.getlist('ingredient_kcal_per_100[]')
        ingredient_protein = request.form.getlist('ingredient_protein[]')
        ingredient_fat = request.form.getlist('ingredient_fat[]')
        ingredient_carbs = request.form.getlist('ingredient_carbs[]')
        
        for i in range(len(ingredient_names)):
            name_ing = ingredient_names[i].strip()
            if not name_ing:
                continue
            
            try:
                # Граммы могут быть пустыми, если используется режим "калории уже посчитаны"
                grams_str = ingredient_grams[i].strip() if i < len(ingredient_grams) and ingredient_grams[i] else ''
                grams = float(grams_str) if grams_str else 0
                
                kcal = float(ingredient_kcal[i] or 0)
                kcal_per_100 = float(ingredient_kcal_per_100[i]) if (i < len(ingredient_kcal_per_100) and ingredient_kcal_per_100[i] and ingredient_kcal_per_100[i].strip()) else None
                protein = float(ingredient_protein[i]) if (i < len(ingredient_protein) and ingredient_protein[i] and ingredient_protein[i].strip()) else None
                fat = float(ingredient_fat[i]) if (i < len(ingredient_fat) and ingredient_fat[i] and ingredient_fat[i].strip()) else None
                carbs = float(ingredient_carbs[i]) if (i < len(ingredient_carbs) and ingredient_carbs[i] and ingredient_carbs[i].strip()) else None
                
                ingredient = Ingredient(
                    dish_id=dish.id,
                    name=name_ing,
                    grams=grams,
                    kcal=kcal,
                    kcal_per_100=kcal_per_100,
                    protein=protein,
                    fat=fat,
                    carbs=carbs,
                    calculated_flag=bool(kcal_per_100)
                )
                db.session.add(ingredient)
            except (ValueError, IndexError):
                continue
        
        db.session.commit()
        flash('Блюдо успешно обновлено!', 'success')
        return redirect(url_for('dishes.dish_view', id=dish.id))
    
    return render_template('dish_edit.html', dish=dish)

@dishes_bp.route('/dish/<int:id>/delete', methods=['POST'])
def dish_delete(id):
    """Удаление блюда"""
    dish = Dish.query.get_or_404(id)
    db.session.delete(dish)
    db.session.commit()
    flash('Блюдо успешно удалено!', 'success')
    return redirect(url_for('dishes.index'))

