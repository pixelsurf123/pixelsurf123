from flask import Blueprint, jsonify, request
from db import db
from models import Dish, Ingredient

api_bp = Blueprint('api', __name__)

@api_bp.route('/shift_back/<int:dish_id>', methods=['POST'])
def shift_back(dish_id):
    """Переносит блюдо на предыдущий день"""
    try:
        dish = Dish.query.get_or_404(dish_id)
        dish.shift_back_one_day()
        return jsonify({
            'success': True,
            'message': 'Блюдо перенесено на предыдущий день',
            'new_date': dish.created_at.isoformat()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/shift_forward/<int:dish_id>', methods=['POST'])
def shift_forward(dish_id):
    """Переносит блюдо на следующий день"""
    try:
        dish = Dish.query.get_or_404(dish_id)
        dish.shift_forward_one_day()
        return jsonify({
            'success': True,
            'message': 'Блюдо перенесено на следующий день',
            'new_date': dish.created_at.isoformat()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@api_bp.route('/toggle_calculated/<int:ingredient_id>', methods=['POST'])
def toggle_calculated(ingredient_id):
    """Переключает флаг calculated_flag для ингредиента"""
    try:
        ingredient = Ingredient.query.get_or_404(ingredient_id)
        ingredient.toggle_calculated()
        return jsonify({
            'success': True,
            'message': 'Флаг обновлен',
            'calculated_flag': ingredient.calculated_flag
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

